from datetime import date
name = 'Markus'
date = date.today()
day2 = 'Tuesday'

print("Hello, my name is", name, "and today it is", str(date), 'which is a', day2, end='.' '\n',)
