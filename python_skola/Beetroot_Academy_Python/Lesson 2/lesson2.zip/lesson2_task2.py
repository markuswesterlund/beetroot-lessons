from datetime import date

firstName = 'Markus'
lastName = 'Westerlund'
day = date.today()
print("Hello, my name is ", firstName, '', lastName, "today is", str(day), end='.' '\n')
